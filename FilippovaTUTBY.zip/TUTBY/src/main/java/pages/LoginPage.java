package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by VALERA on 11.07.2016.
 */
public class LoginPage {

    @FindBy(id = "Username")
    public WebElement loginField;

    @FindBy(id = "Password")
    public WebElement passwordField;

    @FindBy(css = "input[value='Войти']")
    public WebElement loginButton;

    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void loginAs(String name, String pass) {
        loginField.sendKeys(name);
        passwordField.sendKeys(pass);
        loginButton.click();

    }

}
