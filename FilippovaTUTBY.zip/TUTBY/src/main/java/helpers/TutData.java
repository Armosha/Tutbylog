package helpers;

import org.testng.annotations.DataProvider;

/**
 * Created by VALERA on 13.07.2016.
 */
public class TutData {
    @DataProvider(name = "logindata")
    public static Object[][] pages() {
        return new Object[][]{
                {"seleniumweb", "12309876"},
        };
    }
}
