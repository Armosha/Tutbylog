package base;

import helpers.BrowserFactory;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;


public class TestBase {
    public WebDriver driver;
    protected Logger logger;


    @BeforeClass
    public void setUp() {
        logger = Logger.getLogger("tutbyLogger");
        logger.debug("driver gets specific value of browser and url");
        driver = BrowserFactory.getDriver("Firefox", "https://mail.tut.by/");
    }

    @AfterClass
    public void tearDown() {
        logger.debug("driver closes");
        driver.quit();
    }

}